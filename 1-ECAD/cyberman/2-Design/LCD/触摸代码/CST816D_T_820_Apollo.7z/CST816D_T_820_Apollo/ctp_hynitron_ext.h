/**
 *Name        : ctp_hynitron_ext.h
 *Author      : gary
 *Version     : V1.0
 *Create      : 2017-11-23
 *Copyright   : zxzz
 */


#ifndef CTP_HYNITRON_EXT_H__
#define CTP_HYNITRON_EXT_H__

extern kal_bool ctp_hynitron_update(void);

#endif /*CTP_HYNITRON_EXT_H__*/


